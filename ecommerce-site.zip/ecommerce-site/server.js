const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const Product = require('./models/Product');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());
app.use(express.static('public'));

// Connexion à MongoDB
mongoose.connect('mongodb://localhost:27017/ecommerce', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Routes
app.get('/api/products', async (req, res) => {
  const products = await Product.find();
  res.json(products);
});

app.post('/api/cart', (req, res) => {
  // Logique simplifiée pour le panier
  res.json({ message: 'Produit ajouté au panier', cart: req.body });
});

app.listen(port, () => {
  console.log(`Serveur en cours sur le port ${port}`);
});
