async function fetchProducts() {
  const response = await fetch('/api/products');
  const products = await response.json();
  const productsDiv = document.getElementById('products');

  products.forEach(product => {
    const productDiv = document.createElement('div');
    productDiv.classList.add('product');

    productDiv.innerHTML = `
      <h2>${product.name}</h2>
      <img src="${product.imageUrl}" alt="${product.name}">
      <p>${product.description}</p>
      <p>Prix: ${product.price}€</p>
      <button onclick="addToCart('${product._id}')">Ajouter au panier</button>
    `;

    productsDiv.appendChild(productDiv);
  });
}

async function addToCart(productId) {
  const response = await fetch('/api/cart', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ productId }),
  });

  const result = await response.json();
  alert(result.message);
}

fetchProducts();
